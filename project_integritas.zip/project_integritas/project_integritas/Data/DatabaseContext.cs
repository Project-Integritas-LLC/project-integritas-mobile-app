﻿using System;
using Microsoft.EntityFrameworkCore;
using project_integritas.Models;

namespace project_integritas.Data
{
    public class DatabaseContext : DbContext
    {
        public DatabaseContext()
        {
        }

        public DatabaseContext(DbContextOptions<DatabaseContext> options) : base(options) { }
        public DbSet<Session> Sessions { get; set; }

        public DbSet<User> Users { get; set; }

        public DbSet<Utterance> Utterances { get; set; }
    }

}
