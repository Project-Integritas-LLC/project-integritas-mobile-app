using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using project_integritas.Data;
using project_integritas.Models;

namespace project_integritas.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UtteranceController : ControllerBase
    {
        private readonly DatabaseContext _context;

        public UtteranceController(DatabaseContext context)
        {
            _context = context;
        }

        // GET: api/Utterance
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Utterance>>> GetUtterances()
        {
            return await _context.Utterances.ToListAsync();
        }

        // GET: api/Utterance/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Utterance>> GetUtterance(int id)
        {
            var utterance = await _context.Utterances.FindAsync(id);

            if (utterance == null)
            {
                return NotFound();
            }

            return utterance;
        }

        // PUT: api/Utterance/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutUtterance(int id, Utterance utterance)
        {
            if (id != utterance.Id)
            {
                return BadRequest();
            }

            _context.Entry(utterance).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!UtteranceExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Utterance
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public async Task<ActionResult<Utterance>> PostUtterance(Utterance utterance)
        {
            _context.Utterances.Add(utterance);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetUtterance", new { id = utterance.Id }, utterance);
        }

        // DELETE: api/Utterance/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Utterance>> DeleteUtterance(int id)
        {
            var utterance = await _context.Utterances.FindAsync(id);
            if (utterance == null)
            {
                return NotFound();
            }

            _context.Utterances.Remove(utterance);
            await _context.SaveChangesAsync();

            return utterance;
        }

        private bool UtteranceExists(int id)
        {
            return _context.Utterances.Any(e => e.Id == id);
        }
    }
}
