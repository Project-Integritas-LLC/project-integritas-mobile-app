﻿using System;
using System.ComponentModel.DataAnnotations;

namespace project_integritas.Models
{
    public class Utterance
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public String Content { get; set; }

        [Required]
        public int SessionId { get; set; }
    }
}
