﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace project_integritas.Models
{
    public class User
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public String Name { get; set; }

        public ICollection<Session> Sessions { get; set; }
    }
}
