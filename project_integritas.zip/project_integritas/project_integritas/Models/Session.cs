﻿using System;
using System.Collections.Generic;

namespace project_integritas.Models
{
    public class Session
    {
        public int Id { get; set; }

        public string Owner { get; set; }

        public ICollection<Utterance> Utterances { get; set; }
    }
}
