using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using project_integritas.Data;
using project_integritas.Models;

namespace project_integritas
{
    public class Program
    {
        public static void Main(string[] args)
        {
            CreateHostBuilder(args).Build().Run();
            seedDatabase();

        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseStartup<Startup>();
                });

        public static void seedDatabase()
        {
            using Data.DatabaseContext context = new DatabaseContext();
            Session firstSession = new Session()
            {
                Owner = "User"
            };

            Utterance firstUtterance = new Utterance()
            {
                Content = "Hello this is my first utterance"
            };
            Utterance secondUtterance = new Utterance()
            {
                Content = "Hello this is my second utterance"
            };
            firstUtterance.SessionId = firstSession.Id;
            secondUtterance.SessionId = firstSession.Id;

            firstSession.Utterances = new List<Utterance> { firstUtterance, secondUtterance };

            context.Add(firstSession);
            context.Add(firstUtterance);
            context.Add(secondUtterance);

            context.SaveChanges();
        }
    }
}
